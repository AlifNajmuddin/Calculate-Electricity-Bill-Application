package com.example.electricitybill;

import static com.example.electricitybill.R.*;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class CalculateActivity extends AppCompatActivity {

    Toolbar calculateToolbar;
    TextView tvTotalCost, tvBeforeRebate, tvRebate;
    SeekBar sbRebate;
    Button btnCalculate, btnClear;
    TextInputEditText etUsage;  // Declare the TextInputEditText

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_calculate);

        calculateToolbar = findViewById(R.id.calculate_toolbar);

        tvTotalCost = findViewById(R.id.tvTotalCost);
        tvBeforeRebate = findViewById(R.id.tvBeforeRebate);
        tvRebate = findViewById(R.id.tvRebate);
        sbRebate = findViewById(R.id.sbRebate);
        btnCalculate = findViewById(R.id.btnCalculate);
        btnClear = findViewById(R.id.btnClear);


        etUsage = findViewById(R.id.textInputEditText);

        setSupportActionBar(calculateToolbar);
        getSupportActionBar().setTitle("Calculate Bills");

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        // Set SeekBar change listener for rebate percentage
        sbRebate.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                tvRebate.setText("Rebate percentage: " + progress + "%");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        // Calculate button listener
        btnCalculate.setOnClickListener(v -> {
            String usageText = etUsage.getText().toString();  // Get the usage input

            if (usageText.isEmpty()) {
                Toast.makeText(CalculateActivity.this, "Please enter the usage in kWh", Toast.LENGTH_SHORT).show();
                return;
            }

            // Parse the input usage
            double usage = Double.parseDouble(usageText);
            int rebatePercentage = sbRebate.getProgress();

            // Calculate total cost before rebate
            double totalCostBeforeRebate = calculateElectricityBill(usage);

            // Apply rebate
            double rebateAmount = totalCostBeforeRebate * rebatePercentage / 100;
            double totalCost = totalCostBeforeRebate - rebateAmount;

            // Update UI with the calculated values
            tvBeforeRebate.setText("Total Cost before Rebate: RM " + String.format("%.2f", totalCostBeforeRebate));
            tvTotalCost.setText("Total Cost: RM " + String.format("%.2f", totalCost));
        });

        // Clear button listener
        btnClear.setOnClickListener(v -> {
            etUsage.setText("");  // Clear the TextInputEditText
            tvTotalCost.setText("Total Cost: RM 0.00");
            tvBeforeRebate.setText("Cost before rebate: RM 0.00");
            tvRebate.setText("Rebate percentage: 0%");
            sbRebate.setProgress(0);
        });

        // Apply window insets listener for Edge to Edge
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

    }
    public boolean onOptionsItemSelected(MenuItem item){
        if (item.getItemId() == android.R.id.home){

            super.onBackPressed();

        }
        return true;
    }

    // Method to calculate the electricity bill based on usage
    private double calculateElectricityBill(double usage) {
        double totalCost = 0.0;

        if (usage <= 200) {
            totalCost = usage * 21.8;
        } else if (usage <= 300) {
            totalCost = 200 * 21.8 + (usage - 200) * 33.4;
        } else if (usage <= 600) {
            totalCost = 200 * 21.8 + 100 * 33.4 + (usage - 300) * 51.6;
        } else {
            totalCost = 200 * 21.8 + 100 * 33.4 + 300 * 51.6 + (usage - 600) * 54.6;
        }

        return totalCost / 100;
    }
}
